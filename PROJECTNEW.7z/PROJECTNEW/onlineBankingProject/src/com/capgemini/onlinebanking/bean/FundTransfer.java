package com.capgemini.onlinebanking.bean;

import java.sql.Date;

public class FundTransfer
{
    private int FundTransferID;
    private int AccountID;
    private int PayeeAccountID;
    private Date DateOfTransfer;
    private int TransferAmount;
    
    public FundTransfer() {
		// TODO Auto-generated constructor stub
	}

	public FundTransfer(int fundTransferID, int accountID, int payeeAccountID,
			Date dateOfTransfer, int transferAmount) {
		super();
		FundTransferID = fundTransferID;
		AccountID = accountID;
		PayeeAccountID = payeeAccountID;
		DateOfTransfer = dateOfTransfer;
		TransferAmount = transferAmount;
	}

	public int getFundTransferID() {
		return FundTransferID;
	}

	public void setFundTransferID(int fundTransferID) {
		FundTransferID = fundTransferID;
	}

	public int getAccountID() {
		return AccountID;
	}

	public void setAccountID(int accountID) {
		AccountID = accountID;
	}

	public int getPayeeAccountID() {
		return PayeeAccountID;
	}

	public void setPayeeAccountID(int payeeAccountID) {
		PayeeAccountID = payeeAccountID;
	}

	public Date getDateOfTransfer() {
		return DateOfTransfer;
	}

	public void setDateOfTransfer(Date dateOfTransfer) {
		DateOfTransfer = dateOfTransfer;
	}

	public int getTransferAmount() {
		return TransferAmount;
	}

	public void setTransferAmount(int transferAmount) {
		TransferAmount = transferAmount;
	}
    
	
    
}
