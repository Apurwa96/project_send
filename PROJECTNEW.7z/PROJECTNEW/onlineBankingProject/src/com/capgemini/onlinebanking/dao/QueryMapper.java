package com.capgemini.onlinebanking.dao;

public interface QueryMapper 
{	
	
	public static final String TRCKTRANQRY=      "SELECT * FROM transactions WHERE account_id=? ";
	public static final String SERVICETRACKQRY=  "SELECT * FROM service_tracker WHERE service_id=?";	
	
		
	public static final String INSERTCUSTQRY= 		 		"INSERT ALL INTO Customer VALUES(applicationId.NEXTVAL,?,?,?,?,?) INTO Account_Master VALUES(applicationId.NEXTVAL,?,?,SYSDATE) SELECT * FROM dual";
	public static final String SEARCHACQRY= 				"SELECT account_id from Account_Master where account_id=?";
	public static final String CUSTOMERID_QUERY_SEQUENCE=	"SELECT applicationId.CURRVAL FROM DUAL";
	public static final String DISPLAYOLDMOBADDQRY= 	 	"SELECT mobile_no, Address FROM Customer where account_id=?";
	public static final String UPDATEMOBADDQRY=      		"UPDATE Customer SET mobile_no=?, Address=? where account_id=?";
			
	public static final String INSERTUSERQRY= 	 "INSERT INTO usertable VALUES(?,?,?,?,?,?,?,?)";
	public static final String SEARCHUSERQRY= 	 "SELECT account_id from UserTable where account_id=?";
	public static final String FINDUSER= 		 "SELECT login_password from userTable where user_id like ?";
	public static final String GETOLDPWD= 		 "SELECT login_password from userTable where  account_id=?";
	public static final String UPDATEPASSQRY=    "UPDATE usertable SET login_password=? where account_id=?";
	
	
	public static final String CHECKBOOKQUERY= 			 	"INSERT into service_tracker values(serviceId.NEXTVAL,'Request For Chequebook',?,SYSDATE,'Approved and Being Processed')";
	public static final String SERVICEID_QUERY_SEQUENCE=	"SELECT serviceId.CURRVAL FROM DUAL";
	
	public static final String VIEWMINISTMNT=		   "SELECT * FROM transactions WHERE account_id=? AND rownum<=10 ORDER BY dateoftransaction DESC";
	public static final String VIEWDETAILEDSTMNT=      "SELECT * FROM transactions WHERE account_id=? AND (DateofTransaction BETWEEN ? AND ?) ORDER BY DateofTransaction DESC";

	public static final String DEDUCTAMOUNTQUERY=    "UPDATE Account_Master SET account_balance=account_balance-? where account_id=?";
	public static final String ADDAMOUNTQUERY=    "UPDATE Account_Master SET account_balance=account_balance-? where account_id=?";
	
	public static final String ADDTRANQUERY= 	 "INSERT INTO TRANSACTIONS VALUES(transactionId.NEXTVAL,'money RECEIVED',SYSDATE,'CREDIT',?,?)";
	public static final String DEDUCTTRANQUERY= 	 "INSERT INTO TRANSACTIONS VALUES(transactionId.CURRVAL,'money SENT',SYSDATE,'DEBIT',?,?)";
	
	
}
