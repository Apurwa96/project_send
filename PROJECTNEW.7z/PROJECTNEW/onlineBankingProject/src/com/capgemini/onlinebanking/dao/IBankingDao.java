package com.capgemini.onlinebanking.dao;



import java.sql.Date;
import java.util.ArrayList;

import com.capgemini.onlinebanking.bean.Account;
import com.capgemini.onlinebanking.bean.Customer;
import com.capgemini.onlinebanking.bean.ServiceTracker;
import com.capgemini.onlinebanking.bean.Transaction;
import com.capgemini.onlinebanking.bean.UserTable;
import com.capgemini.onlinebanking.exception.BankingException;

public interface IBankingDao {
	public int addAcHolderDetails(Customer customer, Account account) throws BankingException;
	public String addUserDatabase(UserTable user) throws BankingException;
	public boolean searchAccount(int accountId) throws BankingException;
	public boolean searchInUser(int accountId) throws BankingException;
	public boolean getCustomerLogin(String user_name, String password) throws BankingException;
	public Customer fetchMobAddDetails(int accountId ) throws BankingException;
	public int updateMobAddDetails(String mobileno,String address,int accountId) throws BankingException;
	
	public int requestChequeBook(int accid)throws BankingException;
	public ServiceTracker getServiceDetail(int serviceId ) throws BankingException;
	
	public boolean checkOldPassword(String oldPassword, int accountId) throws BankingException;
	public int updatePassword(String newPassword, int accountId) throws BankingException;
	
	public ArrayList<Transaction> getDetailedStatement(int accountId,Date start, Date end) throws BankingException;
	public ArrayList<Transaction> getMiniStatement(int accountId ) throws BankingException;
	
	public void deductAmount(int accountId, double amount) throws BankingException;
	public void addAmount(int p_accountId,double amount) throws BankingException;
	public void addPayeeTable(int accountId, int p_accountId, String nickName) throws BankingException;
	public void addFundTransfer(int accountId, int p_accountId, double amount) throws BankingException;
	public void addTransaction(int accountId, double amount) throws BankingException;
	public void deductTransaction(int p_accountId, double amount) throws BankingException;
	
	
	
}
