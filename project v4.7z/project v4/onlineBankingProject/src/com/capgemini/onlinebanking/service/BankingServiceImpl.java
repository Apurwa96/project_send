package com.capgemini.onlinebanking.service;


import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.onlinebanking.bean.Account;
import com.capgemini.onlinebanking.bean.Customer;
import com.capgemini.onlinebanking.bean.ServiceTracker;
import com.capgemini.onlinebanking.bean.Transaction;
import com.capgemini.onlinebanking.bean.UserTable;
import com.capgemini.onlinebanking.dao.BankingDao;
import com.capgemini.onlinebanking.dao.IBankingDao;
import com.capgemini.onlinebanking.exception.BankingException;

public class BankingServiceImpl implements IBankingService {
	
	IBankingDao bankingDao;

	@Override
	public int addAcHolderDetails(Customer customer, Account account) throws BankingException {
		bankingDao=new BankingDao();
		int custId;
		
		custId=bankingDao.addAcHolderDetails(customer,account);
		return custId;
	}
	
	@Override
	public String addUserDatabase(UserTable user) throws BankingException{
		bankingDao=new BankingDao();
		String userTid;
		
		userTid=bankingDao.addUserDatabase(user);
		return userTid;
	}

	@Override
	public boolean searchAccount(int accountId) throws BankingException {
		bankingDao=new BankingDao();
		return bankingDao.searchAccount(accountId);
	}

	@Override
	public boolean searchInUser(int accountId) throws BankingException {
		bankingDao=new BankingDao();
		return bankingDao.searchInUser(accountId);
	}

	@Override
	public boolean getAdminLogin(String user_name, String password) {
		if(user_name.equals("admin") && password.equals("capgemini123"))
		{
			System.out.println("Login Successful");
			return true;
		}
		else
		{
			System.out.println("Login Failed");
			return false;
		}
	}

	@Override
	public boolean getCustomerLogin(String user_name, String password) throws BankingException {
		
		bankingDao=new BankingDao();
		return bankingDao.getCustomerLogin(user_name,password);
	}

	@Override
	public int updateMobAddDetails(String mobileno, String address,
			int accountId) throws BankingException {
		bankingDao=new BankingDao();
		return bankingDao.updateMobAddDetails(mobileno, address, accountId);
	}

	@Override
	public Customer fetchMobAddDetails(int accountId) throws BankingException {
		
		bankingDao=new BankingDao();
		return bankingDao.fetchMobAddDetails(accountId);
	}

	@Override
	public int requestChequeBook(int accountId) throws BankingException {
		
		bankingDao=new BankingDao();
		return bankingDao.requestChequeBook(accountId);
	}

	@Override
	public ServiceTracker getServiceDetail(int serviceId)
			throws BankingException {
		// TODO Auto-generated method stub
		
		bankingDao=new BankingDao();
		return bankingDao.getServiceDetail(serviceId);
	}

	@Override
	public boolean checkOldPassword(String oldPassword, int accountId)
			throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.checkOldPassword(oldPassword, accountId);
	}

	@Override
	public int updatePassword(String newPassword, int accountId)
			throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.updatePassword(newPassword, accountId);
	}

	@Override
	public ArrayList<Transaction> getDetailedStatement(int accountId,
			Date start, Date end) throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.getDetailedStatement(accountId, start, end);
	}

	@Override
	public ArrayList<Transaction> getMiniStatement(int accountId)
			throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.getMiniStatement(accountId);
	}

	@Override
	public boolean transferAmount(int accountId, int p_accountId,
			double amount, String nickName) throws BankingException{
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		try
		{
		bankingDao.deductAmount(accountId,amount);
		bankingDao.addAmount(p_accountId,amount);
		bankingDao.addFundTransfer(accountId,p_accountId,amount);
		bankingDao.addPayeeTable(accountId,p_accountId,nickName);
		bankingDao.deductTransaction(accountId,amount);
		bankingDao.addTransaction(p_accountId,amount);
			return true;
			
		}catch(Exception e)
		{
			 throw new BankingException(e.getMessage());
		}
		
	}

	@Override
	public ArrayList<Transaction> viewAllTransactions() throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.viewAllTransactions();
	}

	@Override
	public String getQuestion(int accountId) throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.getQuestion(accountId);
	}

	@Override
	public String getAnswer(int accountId) throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.getAnswer(accountId);
	}

	@Override
	public boolean setNewPassword(int accountId) throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.setNewPassword(accountId);
	}

	@Override
	public double getBalance(int accountId) throws BankingException {
		// TODO Auto-generated method stub		
		bankingDao=new BankingDao();
		return bankingDao.getBalance(accountId);
	}
	
	@Override
	public int getAccountId(String username) throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.getAccountId(username);
	}
	
	@Override
	public int getServiceId(int accountId) throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.getServiceId(accountId);
	}

	@Override
	public String getTranPass(int accountId) throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		return bankingDao.getTranPass(accountId);
	}

	
	@Override
	public boolean usernameCheck(String username) throws BankingException {
		// TODO Auto-generated method stub
		bankingDao=new BankingDao();
		ArrayList<String> list=bankingDao.getAllUsername();
		for (String string : list) {
			if(string.equals(username))
			{
				System.out.println("Username already exists");
				System.out.println("---------------------------");
				return false;
			}
			
		}
		return true;
	}

	@Override
	public List<String> customerValidated(Customer cus) {
		List<String> errorList = new ArrayList<String>();
		//if(errorList!=null) errorList=null;

		Pattern pattern = null;
		Matcher matcher = null;

		// Customer Name Validation
		pattern = Pattern.compile("^[A-Za-z\\s]{3,25}$");
		matcher = pattern.matcher(cus.getCustomerName());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Name");
		}

		// Phone Number Validation
		pattern = Pattern.compile("[789][0-9]{9}");
		//pattern = Pattern.compile("[+]?[0-9]{2}[-][0-9]{10}");
		matcher = pattern.matcher(cus.getMobileNo());
		if (!matcher.matches()) {
			errorList.add("Phone Number should be of 10 digits");
		}
		

		// Mail Validation
		pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		matcher = pattern.matcher(cus.getEmail());
		if (!matcher.matches()) {
			errorList.add("Please enter in valid Email format");
		}
		
		
		// Address Validation
		pattern = Pattern.compile("^[A-Za-z0-9\\s,./]{3,}$");
		matcher = pattern.matcher(cus.getAddress());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Address");
		}

		// Pancard Validation
		pattern = Pattern.compile("[A-Z]{5}\\d{4}[A-Z]{1}");
		matcher = pattern.matcher(cus.getPancard());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Pancard");
		}
		
		for (String string : errorList) {
			System.err.println(string);
		}
		System.out.println("\n\n");
		return errorList;
	}
	
	@Override
	public List<String> userValidated(UserTable user) {
		List<String> listerr = new ArrayList<String>();
		//if(errorList!=null)	errorList=null;

		Pattern pattern = null;
		Matcher matcher = null;
		// loginPassword Validation
				pattern = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,15})");
				matcher = pattern.matcher(user.getLoginPassword());
				if (!matcher.matches()) {
					listerr.add("login password should be a combination of uppercase letters, lowercase letters, digit and special character ");
					listerr.add("password should be minimum of 6 letters");
				}
			
	      // secretAnswer Validation
		  pattern = Pattern.compile("[a-zA-Z]+\\.?");
		 matcher = pattern.matcher(user.getSecretAnswer());
		  if (!matcher.matches()) {
			  listerr.add("Please enter a valid secretAnswer");
			}
						
			// TrasactionPassword Validation
			pattern = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,15})");
			matcher = pattern.matcher(user.getTrasactionPassword());
			if (!matcher.matches()) {
				listerr.add("Trasaction Password should be a combination of uppercase letters, lowercase letters, digit and special character");
				listerr.add("password should be minimum of 6 letters");
			}						
				
			for (String string : listerr) {
				System.err.println(string);
			}
			
			return listerr;

}
	
	@Override
	public boolean validateAccount(Account ac){
		 
		List<String> errorList = new ArrayList<String>();
	//	if(errorList!=null)	errorList=null;
		String acType;
		
	acType=ac.getAccountType();
	if(acType.equals("current")||acType.equals("saving"))
	System.out.print("");
	else	errorList.add("account type should either be current or saving");
		
	
	if(ac.getAccountBalance()<500){
		errorList.add("minimum balance should be Rs.500");
	}
	
	for (String string : errorList) {
		System.err.println(string);
	}
	if(errorList.isEmpty())
	return true;
	return false;
 }

	@Override
	public List<String> mobAddValidated(String mobno, String address) {
		// TODO Auto-generated method stub
		List<String> errorList = new ArrayList<String>();
		
		Pattern pattern = null;
		Matcher matcher = null;

		
		// Phone Number Validation
		pattern = Pattern.compile("[789][0-9]{9}");
		//pattern = Pattern.compile("[+]?[0-9]{2}[-][0-9]{10}");
		matcher = pattern.matcher(mobno);
		if (!matcher.matches()) {
			errorList.add("Phone Number should be of 10 digits");
		}
		

		// Address Validation
		pattern = Pattern.compile("^[A-Za-z0-9\\s,./]{3,}$");
		matcher = pattern.matcher(address);
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Address");
		}

		
		for (String string : errorList) {
			System.err.println(string);
		}
		System.out.println("\n\n");
		return errorList;
	}

	
	

	

}
