package com.capgemini.onlinebanking.service;


import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.onlinebanking.bean.Account;
import com.capgemini.onlinebanking.bean.Customer;
import com.capgemini.onlinebanking.bean.ServiceTracker;
import com.capgemini.onlinebanking.bean.Transaction;
import com.capgemini.onlinebanking.bean.UserTable;
import com.capgemini.onlinebanking.exception.BankingException;


public interface IBankingService {
	
	public int addAcHolderDetails(Customer customer, Account account) throws BankingException;
	
	public String addUserDatabase(UserTable user) throws BankingException;
	public boolean searchAccount(int accountId) throws BankingException;
	public boolean searchInUser(int accountId) throws BankingException;
	public boolean getAdminLogin(String user_name, String password);
	public boolean getCustomerLogin(String user_name, String password) throws BankingException;
	public Customer fetchMobAddDetails(int accountId ) throws BankingException;
	public int updateMobAddDetails(String mobileno,String address,int accountId) throws BankingException;
	
	
	public int requestChequeBook(int accid)throws BankingException;
	public ServiceTracker getServiceDetail(int serviceId ) throws BankingException;
	
	public boolean checkOldPassword(String oldPassword, int accountId) throws BankingException;
	public int updatePassword(String newPassword, int accountId) throws BankingException;
	
	public ArrayList<Transaction> getDetailedStatement(int accountId,Date start, Date end) throws BankingException;
	public ArrayList<Transaction> getMiniStatement(int accountId ) throws BankingException;
	
	public boolean transferAmount(int accountId,int p_accountId, double amount,String nickName) throws BankingException;;
	public ArrayList<Transaction> viewAllTransactions() throws BankingException;
	
	public String getQuestion(int accountId) throws BankingException;
	public String getAnswer(int accountId) throws BankingException;
	public boolean setNewPassword(int accountId) throws BankingException;
	
	public double getBalance(int accountId) throws BankingException;
	
	public List<String> customerValidated(Customer cus);
	public List<String> userValidated(UserTable user);
	
	public boolean validateAccount(Account ac);
	
	public int getAccountId(String username) throws BankingException;
	
	public List<String> mobAddValidated(String mobno, String address);
	
	public int getServiceId(int accountId) throws BankingException;
	public String getTranPass(int accountId) throws BankingException;
	
	public boolean  usernameCheck(String username) throws BankingException;			
}
