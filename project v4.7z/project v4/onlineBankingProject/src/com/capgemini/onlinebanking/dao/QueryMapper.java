package com.capgemini.onlinebanking.dao;

public interface QueryMapper 
{	
	
	public static final String TRCKTRANQRY=      "SELECT * FROM transactions WHERE account_id=? ";
	public static final String SERVICETRACKQRY=  "SELECT * FROM service_tracker WHERE service_id=?";	
	
		
	public static final String INSERTCUSTQRY= 		 		"INSERT ALL INTO Customer VALUES(applicationId.NEXTVAL,?,?,?,?,?) INTO Account_Master VALUES(applicationId.NEXTVAL,?,?,SYSDATE) SELECT * FROM dual";
	public static final String SEARCHACQRY= 				"SELECT account_id from Account_Master where account_id=?";
	public static final String CUSTOMERID_QUERY_SEQUENCE=	"SELECT applicationId.CURRVAL FROM DUAL";
	public static final String DISPLAYOLDMOBADDQRY= 	 	"SELECT mobile_no, Address FROM Customer where account_id=?";
	public static final String UPDATEMOBADDQRY=      		"UPDATE Customer SET mobile_no=?, Address=? where account_id=?";
			
	public static final String INSERTUSERQRY= 	 "INSERT INTO usertable VALUES(?,?,?,?,?,?)";
	public static final String SEARCHUSERQRY= 	 "SELECT account_id from UserTable where account_id=?";
	public static final String FINDUSER= 		 "SELECT login_password from userTable where user_id like ?";
	public static final String GETOLDPWD= 		 "SELECT login_password from userTable where  account_id=?";
	public static final String UPDATEPASSQRY=    "UPDATE usertable SET login_password=? where account_id=?";
	
	
	public static final String CHECKBOOKQUERY= 			 	"INSERT into service_tracker values(serviceId.NEXTVAL,'Request For Chequebook',?,SYSDATE,'Approved and Being Processed')";
	public static final String SERVICEID_QUERY_SEQUENCE=	"SELECT serviceId.CURRVAL FROM DUAL";
	
	public static final String VIEWMINISTMNT=		   "SELECT * FROM transactions WHERE account_id=? AND rownum<=10 ORDER BY dateoftransaction DESC";
	public static final String VIEWDETAILEDSTMNT=      "SELECT * FROM transactions WHERE account_id=? AND (DateofTransaction BETWEEN ? AND ?) ORDER BY DateofTransaction DESC";

	public static final String DEDUCTAMOUNTQUERY=    "UPDATE Account_Master SET account_balance=account_balance-? where account_id=?";
	public static final String ADDAMOUNTQUERY=    "UPDATE Account_Master SET account_balance=account_balance+? where account_id=?";
	
	public static final String ADDTRANQUERY= 	 "INSERT INTO TRANSACTIONS VALUES(transactionId.NEXTVAL,'money RECEIVED',SYSDATE,'C',?,?)";
	public static final String DEDUCTTRANQUERY= 	 "INSERT INTO TRANSACTIONS VALUES(transactionId.NEXTVAL,'money SENT',SYSDATE,'D',?,?)";
	
	public static final String PAYEETABLEQUERY= 	 "INSERT INTO PAYEE_TABLE VALUES(?,?,?)";
	public static final String ADDFUNDTRANSFERQUERY= 	 "INSERT INTO fund_transfer VALUES(fundTranId.NEXTVAL,?,?,SYSDATE,?)";
	
	public static final String VIEWALLTRAN=		   "SELECT * FROM transactions";
	
	public static final String VIEWSECQUES=		   "SELECT secret_question FROM usertable WHERE account_id=?";
	public static final String VIEWSECANS=		   "SELECT secret_answer FROM usertable WHERE account_id=?";
	public static final String UPDATEDEFPASS=	"UPDATE usertable SET login_password='Sbq500#' where account_id=?";
	public static final String GETBALANCE=		   "SELECT account_balance FROM account_master WHERE account_id=?";
	
	public static final String GETACID= 		 "SELECT account_id from userTable where user_id like ?";
	public static final String GETSERVICEID= 		 "SELECT service_id from service_tracker where account_id=?";
	
	public static final String GETTRANPASS=		   "SELECT transaction_password FROM usertable WHERE account_id=?";
	
	public static final String GETUSERNAMES=		   "SELECT user_id FROM usertable";
	
	
	
}
