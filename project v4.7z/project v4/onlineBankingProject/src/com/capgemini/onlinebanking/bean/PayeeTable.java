package com.capgemini.onlinebanking.bean;

public class PayeeTable 
{

    private int AccountID;
    private int payeeaccountId;
    private String Nickname;
    
    public PayeeTable() {
		// TODO Auto-generated constructor stub
	}

	public PayeeTable(int accountID, int payeeaccountId, String nickname) {
		super();
		AccountID = accountID;
		this.payeeaccountId = payeeaccountId;
		Nickname = nickname;
	}

	public int getAccountID() {
		return AccountID;
	}

	public void setAccountID(int accountID) {
		AccountID = accountID;
	}

	public int getPayeeaccountId() {
		return payeeaccountId;
	}

	public void setPayeeaccountId(int payeeaccountId) {
		this.payeeaccountId = payeeaccountId;
	}

	public String getNickname() {
		return Nickname;
	}

	public void setNickname(String nickname) {
		Nickname = nickname;
	}
    
    
    
}
